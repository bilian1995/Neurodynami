% Preprocessing.

%tic
BWV_827 = miraudio('Patita No.2 BWV 826.wav');

 a = mirfilterbank(BWV_827,'Gammatone','Hop',1,'NbChannels',5,'Scheirer');% Filterbank simulated cochlea.

mirsave(a);

[a_1,fs] = audioread('Patita No.2 BWV 826.mir.wav');

% transfer to log domain;
a_1 = log(a_1.*(a_1>=0));
%a_1 = a_1(1:200000,:);

input_1 = MeddisHairCell(a_1,fs);
figure();plot(input_1);

%audiowrite('music.wav',input,fs);
% toc

