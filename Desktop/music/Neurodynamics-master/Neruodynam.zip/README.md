# Neurodynamics
Neurodynamics 2015 project
