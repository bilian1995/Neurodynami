%initial

%N = 5; % number of parallels.
%time = 200;
disp('Initializing...');
I = input_1';
r = zeros(6,1);

r(:,1) = I(:,1);
I = I - repmat(I(:,1),[1,size(I,2)]);
I = (I > 0) .* repmat(r(:,1),[1,size(I,2)]) + I;

%c = zeros(1,numel(I)/6+1);
disp('Complete');
%i = 5;
disp('Running Channels');
for i = 2:6
 Z = I(i,:);
 
 a = feature_detection(numel(Z)*0.05,Z);
 b = a>-15;
 
 c = c + b(4,:);
 fprintf('%d running complete\n',i);
 
end

plot(c)