function [V_1] = feature_detection(t,I_ex)
% Constants
C_m  = 1.0; % membrane capacitance, in uF/cm^2


% System definition
N = 5;
%sim_time = 120;
step = 0.05;
%time = 0:step:sim_time;
time = 0:step:t;
%t_0 = 0;
%plot(I_ex);
V = zeros(N, length(time));

V_synapse = zeros(N);
V_nmda = zeros(N);

m = zeros(N, length(time));
h = zeros(N, length(time));
n = zeros(N, length(time));
slow = zeros(N, length(time));
V(:, 1) = -68;
m(:, 1) = 0.053;
h(:, 1) = 0.596;
n(:, 1) = 0.318;
slow(:, 1) = 0;
dmdt = zeros(N, 1);
dhdt = zeros(N, 1);
dndt = zeros(N, 1);
dslowdt = zeros(N, 1);
I_self = zeros(N, 1);
r = zeros(N);
%drdt = zeros(N);
topo_e = zeros(N);
topo_i = zeros(N);
topo_e(1, 2:3) = 1;
topo_e(5, 3) = 1;
topo_e(3, 4) = 1;
topo_i(2, 4:5) = 1;


%I_ext = (10+10*rand(N,1))*ones(1, length(time));
%I_ext = [20; 0] * ones(1, length(time));
%I_ext(1, 1:1000) = 0;
I_ext = zeros(N, length(time)-1);
%fprintf('%d,%d',size(I_ex),size(I_ext));
%plot(I_ex(:))

I_ext(1,:) = I_ex(:);
%I_ext(1, 1001:1200) = 40;
% I_ext(3, 1001:1300) = [linspace(1, 10, 150), linspace(10, 1, 150)];
%I_ext(1, 1701:1800) = 30;
%I_ext(1, 2050:2100) = 30;
%I_ext(1, 601:680) = 30;
%I_ext(1, 701:830) = 40;
% I_ext(5, 1001:1200) = -7;
%plot(I_ext(1,:));
% Parameters
%g_gaba = 20;  % mS/cm^2
%g_glu = 8;
%g = [10, 8, 10, 20, 1, 5];
g = zeros(N);
g(1, 2:3) = [3, 1];
g(2, 4:5) = [0.5, 2];
g(3, 4) = 10;
g(5, 3) = 10;


Ca = zeros(N, N, length(time));
Ca(:,:,1) = 1e-6 * ones(N) .* (topo_i + topo_e);  % Assume Ca concentration independent across synapses
g_1 = [1e-4, 1e-6, 3e-5]; 
g_ampa = zeros(N, N, length(time));
g_ampa(:,:,1) = 1e-2 * ones(N) .* (topo_i + topo_e);
r_ampa = zeros(N) .* (topo_i + topo_e);
r_nmda = zeros(N) .* (topo_i + topo_e);
r_1 = cat(3, r_ampa, r_nmda);
thresh = -20;  % threshold beyond which neuron is considered to have fired


for t = 1:length(time)-2
%    system('pause');
	%[I_self, dmdt, dhdt, dndt, dslowdt] = HH_burst(V(:,t), m(:,t), h(:,t), n(:,t), slow(:,t));
% 	[I_self(1), dmdt(1), dhdt(1), dndt(1)] = HH(V(1,t), m(1,t), h(1,t), n(1,t));
	[I_self(1), dmdt(1), dhdt(1), dndt(1), dslowdt(1)] = AN1(V(1,t), m(1,t), h(1,t), n(1,t), slow(1,t));
% 	[I_self(2), dmdt(2), dhdt(2), dndt(2)] = HH(V(2,t), m(2,t), h(2,t), n(2,t));


	[I_self(2), dmdt(2), dhdt(2), dndt(2), dslowdt(2)] = LN2(V(2,t), m(2,t), h(2,t), n(2,t), slow(2,t));
	[I_self(3), dmdt(3), dhdt(3), dndt(3), dslowdt(3)] = LN3(V(3,t), m(3,t), h(3,t), n(3,t), slow(3,t));
	[I_self(4), dmdt(4), dhdt(4), dndt(4), dslowdt(4)] = HH_burst(V(4,t), m(4,t), h(4,t), n(4,t), slow(4,t));
	[I_self(5), dmdt(5), dhdt(5), dndt(5), dslowdt(5)] = LN5(V(5,t), m(5,t), h(5,t), n(5,t), slow(5, t));
    
	%[I_syn, dVdt_nmda, dVdt_synapse, dCadt, dgdt_ampa, drdt] = synapse((topo_i + topo_e), V(:,t), g_1, g_ampa(:,:,t), r_1, V_nmda, Ca(:,:,t));
	%[I_self, dmdt, dhdt, dndt] = HH(V(:,t), m(:,t), h(:,t), n(:,t));
	%[I_self, dmdt, dhdt, dndt] = Oscillate(V(:,t), m(:,t), h(:,t), n(:,t));
	%[I_syn(1), drdt(2)] = inhibitory(V(2,t), V(1,t), g_gaba, r(2));
   
  
	[I_syn_e, drdt_e] = excitatory(topo_e, V(:,t), g, r);

	[I_syn_i, drdt_i] = inhibitory(topo_i, V(:,t), g, r);

    I_syn = sum(I_syn_e + I_syn_i, 1)';
    drdt = drdt_e + drdt_i;
    
% 	[I_syn(1), drdt(1)] = excitatory(V(1,t), V(2,t), g(1), r(1));
% 	[I_syn(2), drdt(2)] = excitatory(V(1,t), V(3,t), g(2), r(2));
% 	[I_syn(3), drdt(3)] = inhibitory(V(2,t), V(5,t), g(3), r(3));
% 	[I_syn(4), drdt(4)] = inhibitory(V(2,t), V(4,t), g(4), r(4));
% 	[I_syn(5), drdt(5)] = excitatory(V(5,t), V(3,t), g(5), r(5));
% 	[I_syn(6), drdt(6)] = excitatory(V(3,t), V(4,t), g(6), r(6));
	%I_total = I_ext(:,t) + I_self; 
    
	I_total = I_ext(:,t) + I_self + I_syn; 
    
	dVdt = I_total / C_m;
	V(:,t+1) = V(:,t) + step*dVdt;
	m(:,t+1) = m(:,t) + step*dmdt;
	h(:,t+1) = h(:,t) + step*dhdt;
	n(:,t+1) = n(:,t) + step*dndt;
	slow(:,t+1) = slow(:,t) + step*dslowdt;
    
    % synaptic parameters update
	%V_nmda(:,t+1) = V_nmda(:,t) + step*dVdt_nmda;
	%V_nmda = V_nmda + step*dVdt_nmda;
	%V_synapse = V_synapse + step*dVdt_synapse;
	%Ca(:,:,t+1) = Ca(:,:,t) + step*dCadt;
	%g_ampa(:,:,t+1) = g_ampa(:,:,t) + step*dgdt_ampa;

	% If presynaptic spike occurs, set r_ampa and r_nmda to unity, otherwise update
	%drdt_ampa = drdt(:,:,1);
	%drdt_nmda = drdt(:,:,2);
	%check_spike = ((V(:,t+1) > thresh) .* (V(:,t) < thresh)) * ones(1,N);
	%r_ampa = (check_spike + (r_ampa + step*drdt_ampa) .* (1 - check_spike)) .* topo;
	%r_nmda = (check_spike + (r_nmda + step*drdt_nmda) .* (1 - check_spike)) .* topo;
    %r_1 = cat(3, r_ampa, r_nmda);
    
    r = r + step*drdt;
    % synaptic parameters update
    %r_ampa = r_ampa + step*drdt_ampa;
    %r_nmda = r_nmda + drdt_nmda*step;
end

figure(); plot(time, V(4,:));
V_1 = V;
%figure; plot(time, V);
end
%figure; plot(time, m(5,:), time, n(5,:), time, h(5,:))
%figure; plot(time, slow);




